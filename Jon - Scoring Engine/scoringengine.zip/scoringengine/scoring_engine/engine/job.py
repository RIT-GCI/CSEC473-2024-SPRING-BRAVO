class Job(dict):
    pass
