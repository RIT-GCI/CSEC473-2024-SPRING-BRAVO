from scoring_engine.config_loader import ConfigLoader


config = ConfigLoader()
