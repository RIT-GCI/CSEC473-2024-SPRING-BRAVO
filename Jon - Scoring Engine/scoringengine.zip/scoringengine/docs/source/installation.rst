Installation
************

.. toctree::
  :maxdepth: 2

  installation/docker
  installation/manual


