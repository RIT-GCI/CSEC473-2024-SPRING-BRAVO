Screenshots
===========

Scoreboard
^^^^^^^^^^

.. image:: images/scoreboard.png
    :scale: 50%

Overview
^^^^^^^^

.. image:: images/overview.png
    :scale: 50%

Team Services
^^^^^^^^^^^^^

.. image:: images/team_services.png
    :scale: 50%

Specific Service
^^^^^^^^^^^^^^^^

.. image:: images/ssh_service.png
    :scale: 50%

Round Status
^^^^^^^^^^^^

.. image:: images/round_status.png
    :scale: 50%

Admin Team View
^^^^^^^^^^^^^^^

.. image:: images/admin_team_view.png
    :scale: 50%
