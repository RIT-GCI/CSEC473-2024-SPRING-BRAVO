VNC
^^^
Connects and if specified, will login to a VNC server

`Uses Accounts (optional)`

Custom Properties: `none`
