SMTP(S)
^^^^^^^
Logs into an SMTP server and sends an email

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50

   * - touser
     - address that the email will be sent to
   * - subject
     - subject of the email
   * - body
     - body of the email
