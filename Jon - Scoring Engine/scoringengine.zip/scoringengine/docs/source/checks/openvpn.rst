OpenVPN
^^^^^^^
Logs into an OpenVPN service using an account/password + CA certificate.

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50
   * - ca
     - entire CA text
