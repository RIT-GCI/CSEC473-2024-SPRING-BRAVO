WinRM
^^^^^
Logs into a system using WinRM with an account/password, and executes command(s)

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50

   * - commands
     - ';' delimited list of commands to run (Ex: ipconfig /all;whoami)
