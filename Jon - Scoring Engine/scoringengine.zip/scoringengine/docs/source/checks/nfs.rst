NFS
^^^
Uses python libnfs to login to an NFS server, write a file, login again to NFS and read a file

Custom Properties:

.. list-table::
   :widths: 25 50

   * - remotefilepath
     - absolute path of file on remote server to upload/download
   * - filecontents
     - contents of the file that we upload/download
