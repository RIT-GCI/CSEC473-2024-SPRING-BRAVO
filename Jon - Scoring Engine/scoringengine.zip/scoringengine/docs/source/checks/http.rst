HTTP(S)
^^^^^^^
Sends a GET request to an HTTP(S) server

Custom Properties:

.. list-table::
   :widths: 25 50

   * - useragent
     - specific useragent to use in the request
   * - vhost
     - vhost used in the request
   * - uri
     - uri of the request
