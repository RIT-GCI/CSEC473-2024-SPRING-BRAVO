MySQL
^^^^^
Logs into a MySQL server, uses a database, and executes a specific SQL command

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50

   * - database
     - database to use before running command
   * - command
     - SQL command that will execute
