FTP
^^^
Uses python ftplib to login to an FTP server, upload a file, login again to FTP and download file

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50

   * - remotefilepath
     - absolute path of file on remote server to upload/download
   * - filecontents
     - contents of the file that we upload/download
