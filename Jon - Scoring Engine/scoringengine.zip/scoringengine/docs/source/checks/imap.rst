IMAP(S)
^^^^^^^
Uses medusa to login to an imap server

`Uses Accounts`

Custom Properties:

.. list-table::
   :widths: 25 50

   * - domain
     - domain of the username
