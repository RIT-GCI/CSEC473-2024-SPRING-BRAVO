ICMP
^^^^
Sends an ICMP Echo Request to server

Custom Properties: `none`
