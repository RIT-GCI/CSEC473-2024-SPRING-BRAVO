Elasticsearch
^^^^^^^^^^^^^
Uses python requests to insert message and then query for same message

Custom Properties:

.. list-table::
   :widths: 25 50

   * - index
     - index to use to insert the message
   * - doc_type
     - type of the document
