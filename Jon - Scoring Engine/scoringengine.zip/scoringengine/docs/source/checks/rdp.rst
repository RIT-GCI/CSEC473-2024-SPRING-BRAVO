RDP
^^^
Logs into a system using RDP with an account/password

`Uses Accounts`

Custom Properties: `none`