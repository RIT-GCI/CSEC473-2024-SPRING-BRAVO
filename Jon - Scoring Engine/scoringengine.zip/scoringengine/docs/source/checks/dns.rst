DNS
^^^
Queries a DNS server for a specific record

Custom Properties:

.. list-table::
   :widths: 25 50

   * - qtype
     - type of record (A, AAAA, CNAME, etc)
   * - domain
     - domain/host to query for
